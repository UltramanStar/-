<template>
  <router-view></router-view>
</template>

<script setup>

</script>

<style scoped>
body {
  background: url(../src/assets/wallpaper.jpg) no-repeat;
  background-size: cover;
  background-attachment: fixed;
}
</style>
