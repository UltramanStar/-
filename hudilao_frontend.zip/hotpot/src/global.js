const showPass = false;
const notShowPass = true;

export default {
    showPass,
    notShowPass,
}