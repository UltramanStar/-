# Summary

Date : 2023-09-12 09:34:50

Directory e:\\restrauntpro\\hotpot\\src

Total : 22 files,  5147 codes, 791 comments, 371 blanks, all 6309 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Vue | 12 | 4,972 | 747 | 344 | 6,063 |
| JavaScript | 9 | 171 | 44 | 27 | 242 |
| CSS | 1 | 4 | 0 | 0 | 4 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 22 | 5,147 | 791 | 371 | 6,309 |
| . (Files) | 5 | 46 | 44 | 11 | 101 |
| api | 3 | 63 | 0 | 11 | 74 |
| common | 1 | 66 | 0 | 6 | 72 |
| stores | 1 | 12 | 0 | 2 | 14 |
| views | 12 | 4,960 | 747 | 341 | 6,048 |
| views (Files) | 6 | 1,920 | 118 | 117 | 2,155 |
| views\\AdminMainArea | 6 | 3,040 | 629 | 224 | 3,893 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)