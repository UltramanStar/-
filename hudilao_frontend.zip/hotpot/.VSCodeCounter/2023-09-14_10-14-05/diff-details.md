# Diff Details

Date : 2023-09-14 10:14:05

Directory e:\\restrauntpro\\hotpot\\src

Total : 7 files,  36 codes, 190 comments, -47 blanks, all 179 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/common/router.js](/src/common/router.js) | JavaScript | 1 | 0 | 0 | 1 |
| [src/views/AdminMainArea/CustomerManage.vue](/src/views/AdminMainArea/CustomerManage.vue) | Vue | -3 | 35 | -12 | 20 |
| [src/views/AdminMainArea/DataReport.vue](/src/views/AdminMainArea/DataReport.vue) | Vue | 0 | 18 | -12 | 6 |
| [src/views/AdminMainArea/DishManage.vue](/src/views/AdminMainArea/DishManage.vue) | Vue | 0 | 35 | -13 | 22 |
| [src/views/AdminMainArea/EmployeeManage.vue](/src/views/AdminMainArea/EmployeeManage.vue) | Vue | 4 | 30 | -11 | 23 |
| [src/views/AdminMainArea/ViewAnnouncement.vue](/src/views/AdminMainArea/ViewAnnouncement.vue) | Vue | 12 | 1 | 1 | 14 |
| [src/views/CookDashBoard.vue](/src/views/CookDashBoard.vue) | Vue | 22 | 71 | 0 | 93 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details