# Summary

Date : 2023-09-14 10:14:05

Directory e:\\restrauntpro\\hotpot\\src

Total : 22 files,  5183 codes, 981 comments, 324 blanks, all 6488 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Vue | 12 | 5,007 | 937 | 297 | 6,241 |
| JavaScript | 9 | 172 | 44 | 27 | 243 |
| CSS | 1 | 4 | 0 | 0 | 4 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 22 | 5,183 | 981 | 324 | 6,488 |
| . (Files) | 5 | 46 | 44 | 11 | 101 |
| api | 3 | 63 | 0 | 11 | 74 |
| common | 1 | 67 | 0 | 6 | 73 |
| stores | 1 | 12 | 0 | 2 | 14 |
| views | 12 | 4,995 | 937 | 294 | 6,226 |
| views (Files) | 6 | 1,942 | 189 | 117 | 2,248 |
| views\\AdminMainArea | 6 | 3,053 | 748 | 177 | 3,978 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)