# Diff Summary

Date : 2023-09-14 10:14:05

Directory e:\\restrauntpro\\hotpot\\src

Total : 7 files,  36 codes, 190 comments, -47 blanks, all 179 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Vue | 6 | 35 | 190 | -47 | 178 |
| JavaScript | 1 | 1 | 0 | 0 | 1 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 7 | 36 | 190 | -47 | 179 |
| common | 1 | 1 | 0 | 0 | 1 |
| views | 6 | 35 | 190 | -47 | 178 |
| views (Files) | 1 | 22 | 71 | 0 | 93 |
| views\\AdminMainArea | 5 | 13 | 119 | -47 | 85 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)