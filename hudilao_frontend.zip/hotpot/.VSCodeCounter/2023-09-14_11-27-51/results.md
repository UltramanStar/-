# Summary

Date : 2023-09-14 11:27:51

Directory e:\\restrauntpro\\hotpot\\src

Total : 22 files,  5181 codes, 1064 comments, 304 blanks, all 6549 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Vue | 12 | 5,005 | 1,020 | 277 | 6,302 |
| JavaScript | 9 | 172 | 44 | 27 | 243 |
| CSS | 1 | 4 | 0 | 0 | 4 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 22 | 5,181 | 1,064 | 304 | 6,549 |
| . (Files) | 5 | 46 | 44 | 11 | 101 |
| api | 3 | 63 | 0 | 11 | 74 |
| common | 1 | 67 | 0 | 6 | 73 |
| stores | 1 | 12 | 0 | 2 | 14 |
| views | 12 | 4,993 | 1,020 | 274 | 6,287 |
| views (Files) | 6 | 1,942 | 225 | 103 | 2,270 |
| views\\AdminMainArea | 6 | 3,051 | 795 | 171 | 4,017 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)