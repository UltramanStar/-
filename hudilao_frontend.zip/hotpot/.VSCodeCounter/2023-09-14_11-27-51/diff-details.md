# Diff Details

Date : 2023-09-14 11:27:51

Directory e:\\restrauntpro\\hotpot\\src

Total : 5 files,  -2 codes, 83 comments, -20 blanks, all 61 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/views/AdminDashBoard.vue](/src/views/AdminDashBoard.vue) | Vue | 0 | 14 | -9 | 5 |
| [src/views/AdminMainArea/HistoryOrder.vue](/src/views/AdminMainArea/HistoryOrder.vue) | Vue | 0 | 21 | -3 | 18 |
| [src/views/AdminMainArea/ViewAnnouncement.vue](/src/views/AdminMainArea/ViewAnnouncement.vue) | Vue | -2 | 26 | -3 | 21 |
| [src/views/Login.vue](/src/views/Login.vue) | Vue | 0 | 10 | -5 | 5 |
| [src/views/OrderItem.vue](/src/views/OrderItem.vue) | Vue | 0 | 12 | 0 | 12 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details