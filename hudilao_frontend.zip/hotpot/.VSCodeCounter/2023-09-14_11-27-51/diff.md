# Diff Summary

Date : 2023-09-14 11:27:51

Directory e:\\restrauntpro\\hotpot\\src

Total : 5 files,  -2 codes, 83 comments, -20 blanks, all 61 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Vue | 5 | -2 | 83 | -20 | 61 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 5 | -2 | 83 | -20 | 61 |
| views | 5 | -2 | 83 | -20 | 61 |
| views (Files) | 3 | 0 | 36 | -14 | 22 |
| views\\AdminMainArea | 2 | -2 | 47 | -6 | 39 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)