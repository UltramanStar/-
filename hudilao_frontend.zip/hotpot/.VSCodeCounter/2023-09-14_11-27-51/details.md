# Details

Date : 2023-09-14 11:27:51

Directory e:\\restrauntpro\\hotpot\\src

Total : 22 files,  5181 codes, 1064 comments, 304 blanks, all 6549 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [src/App.vue](/src/App.vue) | Vue | 12 | 0 | 4 | 16 |
| [src/api/adminapi.js](/src/api/adminapi.js) | JavaScript | 26 | 0 | 2 | 28 |
| [src/api/cookapi.js](/src/api/cookapi.js) | JavaScript | 6 | 0 | 3 | 9 |
| [src/api/manage.js](/src/api/manage.js) | JavaScript | 31 | 0 | 6 | 37 |
| [src/common/router.js](/src/common/router.js) | JavaScript | 67 | 0 | 6 | 73 |
| [src/echarts.js](/src/echarts.js) | JavaScript | 3 | 40 | 2 | 45 |
| [src/global.js](/src/global.js) | JavaScript | 6 | 0 | 1 | 7 |
| [src/main.js](/src/main.js) | JavaScript | 21 | 4 | 4 | 29 |
| [src/stores/CookLoginStore.js](/src/stores/CookLoginStore.js) | JavaScript | 12 | 0 | 2 | 14 |
| [src/style.css](/src/style.css) | CSS | 4 | 0 | 0 | 4 |
| [src/views/AdminDashBoard.vue](/src/views/AdminDashBoard.vue) | Vue | 276 | 21 | 18 | 315 |
| [src/views/AdminMainArea/CustomerManage.vue](/src/views/AdminMainArea/CustomerManage.vue) | Vue | 518 | 101 | 25 | 644 |
| [src/views/AdminMainArea/DataReport.vue](/src/views/AdminMainArea/DataReport.vue) | Vue | 1,017 | 216 | 26 | 1,259 |
| [src/views/AdminMainArea/DishManage.vue](/src/views/AdminMainArea/DishManage.vue) | Vue | 601 | 285 | 47 | 933 |
| [src/views/AdminMainArea/EmployeeManage.vue](/src/views/AdminMainArea/EmployeeManage.vue) | Vue | 408 | 85 | 30 | 523 |
| [src/views/AdminMainArea/HistoryOrder.vue](/src/views/AdminMainArea/HistoryOrder.vue) | Vue | 258 | 51 | 20 | 329 |
| [src/views/AdminMainArea/ViewAnnouncement.vue](/src/views/AdminMainArea/ViewAnnouncement.vue) | Vue | 249 | 57 | 23 | 329 |
| [src/views/CookDashBoard.vue](/src/views/CookDashBoard.vue) | Vue | 1,118 | 157 | 46 | 1,321 |
| [src/views/CookDashBoard.vue.js](/src/views/CookDashBoard.vue.js) | JavaScript | 0 | 0 | 1 | 1 |
| [src/views/Login.vue](/src/views/Login.vue) | Vue | 281 | 31 | 23 | 335 |
| [src/views/OrderItem.vue](/src/views/OrderItem.vue) | Vue | 186 | 15 | 4 | 205 |
| [src/views/Test.vue](/src/views/Test.vue) | Vue | 81 | 1 | 11 | 93 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)